"""
conocimiento.py
---------------
Este módulo se encarga de todo lo relacionado con la "base de conocimiento"
del chatbot: un archivo JSON donde se guardan las categorías de preguntas,
sus patrones (formas de preguntar) y sus posibles respuestas.

Separar esta lógica en su propio archivo permite que el bot "aprenda"
nuevas respuestas sin tener que tocar el código fuente.
"""

import json
import os


def cargar_base_conocimiento(ruta_archivo):
    """
    Carga la base de conocimiento desde un archivo JSON.

    Parámetros:
        ruta_archivo (str): ruta al archivo .json con el conocimiento del bot.

    Retorna:
        dict: diccionario con todas las categorías, patrones y respuestas.
    """
    if not os.path.exists(ruta_archivo):
        # Si el archivo no existe todavía, comenzamos con una base vacía.
        return {}

    with open(ruta_archivo, "r", encoding="utf-8") as archivo:
        return json.load(archivo)


def guardar_base_conocimiento(ruta_archivo, base_conocimiento):
    """
    Guarda (sobrescribe) la base de conocimiento en un archivo JSON.

    Parámetros:
        ruta_archivo (str): ruta al archivo .json donde se guardará.
        base_conocimiento (dict): diccionario actualizado con todo el conocimiento.

    Retorna:
        None
    """
    with open(ruta_archivo, "w", encoding="utf-8") as archivo:
        # indent=2 y ensure_ascii=False hacen que el JSON quede legible,
        # incluso con tildes y eñes.
        json.dump(base_conocimiento, archivo, indent=2, ensure_ascii=False)


def agregar_nuevo_conocimiento(base_conocimiento, categoria, patron, respuesta):
    """
    Agrega un nuevo patrón y/o respuesta a una categoría existente,
    o crea la categoría si todavía no existe.

    Esta función es la que le permite al chatbot "aprender" en tiempo real
    cuando el usuario le enseña algo nuevo.

    Parámetros:
        base_conocimiento (dict): base de conocimiento actual.
        categoria (str): nombre de la categoría (ej: "saludos").
        patron (str): nueva frase de ejemplo que el bot debe reconocer.
        respuesta (str): respuesta que el bot debe dar para esa categoría.

    Retorna:
        dict: base de conocimiento actualizada.
    """
    if categoria not in base_conocimiento:
        # Si la categoría no existe, la creamos desde cero.
        base_conocimiento[categoria] = {"patrones": [], "respuestas": []}

    if patron not in base_conocimiento[categoria]["patrones"]:
        base_conocimiento[categoria]["patrones"].append(patron)

    if respuesta not in base_conocimiento[categoria]["respuestas"]:
        base_conocimiento[categoria]["respuestas"].append(respuesta)

    return base_conocimiento


def listar_categorias(base_conocimiento):
    """
    Devuelve la lista de nombres de categorías disponibles en la base
    de conocimiento. Útil para mostrar información de depuración o ayuda.

    Parámetros:
        base_conocimiento (dict): base de conocimiento actual.

    Retorna:
        list: lista de strings con los nombres de las categorías.
    """
    return list(base_conocimiento.keys())
