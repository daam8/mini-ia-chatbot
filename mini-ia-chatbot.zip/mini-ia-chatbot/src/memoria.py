"""
memoria.py
----------
Este módulo le da al chatbot "memoria" entre sesiones: guarda un historial
de todas las conversaciones en un archivo, con fecha y hora, para que
después se pueda revisar qué se habló.

Esto es útil para la presentación: se puede mostrar el archivo de historial
como evidencia de que el bot funcionó y registró la conversación.
"""

import json
import os
from datetime import datetime


def crear_registro_interaccion(mensaje_usuario, respuesta_bot):
    """
    Crea un diccionario con los datos de una interacción individual
    (una pregunta del usuario y su respectiva respuesta del bot).

    Parámetros:
        mensaje_usuario (str): lo que escribió el usuario.
        respuesta_bot (str): lo que respondió el chatbot.

    Retorna:
        dict: registro con fecha, hora, mensaje y respuesta.
    """
    ahora = datetime.now()
    return {
        "fecha": ahora.strftime("%d/%m/%Y"),
        "hora": ahora.strftime("%H:%M:%S"),
        "usuario": mensaje_usuario,
        "bot": respuesta_bot,
    }


def cargar_historial(ruta_archivo):
    """
    Carga el historial de conversaciones previas desde un archivo JSON.
    Si el archivo no existe todavía, retorna una lista vacía.

    Parámetros:
        ruta_archivo (str): ruta al archivo de historial.

    Retorna:
        list: lista de registros de interacciones anteriores.
    """
    if not os.path.exists(ruta_archivo):
        return []

    with open(ruta_archivo, "r", encoding="utf-8") as archivo:
        try:
            return json.load(archivo)
        except json.JSONDecodeError:
            # Si el archivo está vacío o corrupto, empezamos de nuevo.
            return []


def guardar_historial(ruta_archivo, historial):
    """
    Guarda la lista completa de historial en un archivo JSON.

    Parámetros:
        ruta_archivo (str): ruta al archivo de historial.
        historial (list): lista de registros de interacciones.

    Retorna:
        None
    """
    with open(ruta_archivo, "w", encoding="utf-8") as archivo:
        json.dump(historial, archivo, indent=2, ensure_ascii=False)


def agregar_al_historial(historial, mensaje_usuario, respuesta_bot):
    """
    Agrega una nueva interacción a la lista de historial (en memoria,
    todavía sin guardar en el archivo).

    Parámetros:
        historial (list): lista actual de interacciones.
        mensaje_usuario (str): mensaje escrito por el usuario.
        respuesta_bot (str): respuesta generada por el bot.

    Retorna:
        list: historial actualizado con la nueva interacción al final.
    """
    nuevo_registro = crear_registro_interaccion(mensaje_usuario, respuesta_bot)
    historial.append(nuevo_registro)
    return historial
