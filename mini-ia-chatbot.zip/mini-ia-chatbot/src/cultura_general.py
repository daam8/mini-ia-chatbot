"""
cultura_general.py
-------------------
Este módulo le da al chatbot un pequeño "conocimiento del mundo", para que
pueda responder preguntas básicas de cultura general del tipo:
    - "¿Qué es el sol?"
    - "¿Qué es Python?"
    - "¿Qué es la inteligencia artificial?"

Funciona 100% sin conexión a internet: toda la información está guardada
en un diccionario dentro del propio código. Esto es ideal para una
demostración en clase, porque no depende de APIs externas ni de conexión.

Se puede ampliar fácilmente agregando más entradas al diccionario
DICCIONARIO_GENERAL.
"""

import re

# Diccionario con definiciones cortas de temas comunes.
# La clave siempre debe estar en minúsculas y sin acentos (texto normalizado).
DICCIONARIO_GENERAL = {
    "sol": "El Sol es la estrella que está en el centro de nuestro sistema solar. "
           "Es una enorme esfera de gas caliente que genera luz y calor mediante reacciones nucleares.",
    "luna": "La Luna es el único satélite natural de la Tierra. Gira alrededor de "
            "nuestro planeta y es responsable de fenómenos como las mareas.",
    "tierra": "La Tierra es el tercer planeta del sistema solar y el único conocido "
              "hasta ahora que tiene condiciones para albergar vida.",
    "universo": "El universo es todo lo que existe: el espacio, el tiempo, la materia "
                "y la energía, incluyendo las galaxias, estrellas y planetas.",
    "internet": "Internet es una red mundial que conecta millones de computadoras entre sí, "
                "permitiendo compartir información e intercambiar datos a distancia.",
    "computadora": "Una computadora es una máquina electrónica capaz de recibir datos, "
                   "procesarlos siguiendo instrucciones (programas) y entregar un resultado.",
    "wifi": "El wifi es una tecnología que permite conectar dispositivos a internet "
            "de forma inalámbrica, usando ondas de radio en lugar de cables.",
    "inteligencia artificial": "La inteligencia artificial es una rama de la informática que "
                                "busca crear programas capaces de realizar tareas que normalmente "
                                "requieren inteligencia humana, como reconocer patrones o tomar decisiones.",
    "ia": "IA son las siglas de Inteligencia Artificial: programas diseñados para "
          "imitar ciertas capacidades del razonamiento humano.",
    "algoritmo": "Un algoritmo es una secuencia ordenada y finita de pasos que permite "
                 "resolver un problema o realizar una tarea específica.",
    "python": "Python es un lenguaje de programación fácil de leer y muy popular, usado "
              "para desarrollar desde páginas web hasta inteligencia artificial.",
    "programacion": "La programación es el proceso de escribir instrucciones (código) "
                    "para que una computadora realice una tarea específica.",
    "software": "El software es el conjunto de programas e instrucciones que le dicen "
                "a una computadora qué hacer. A diferencia del hardware, no se puede tocar.",
    "hardware": "El hardware son las partes físicas de una computadora: el teclado, "
                "la pantalla, el procesador, la memoria, etc.",
    "base de datos": "Una base de datos es un sistema organizado para guardar, buscar "
                      "y administrar grandes cantidades de información de manera eficiente.",
    "gravedad": "La gravedad es la fuerza que atrae a los objetos con masa hacia el centro "
                "de un planeta o cuerpo celeste; es la razón por la que las cosas caen al suelo.",
    "agua": "El agua es una sustancia formada por hidrógeno y oxígeno (H2O), esencial "
            "para la vida en la Tierra.",
    "fotosintesis": "La fotosíntesis es el proceso mediante el cual las plantas transforman "
                    "la luz solar, el agua y el dióxido de carbono en energía y oxígeno.",
    "atomo": "Un átomo es la unidad más pequeña de la materia que conserva las propiedades "
             "de un elemento químico.",
    "adn": "El ADN es una molécula que contiene la información genética de los seres vivos, "
           "como si fuera el 'manual de instrucciones' de cada organismo.",
    "robot": "Un robot es una máquina programable capaz de realizar tareas de forma "
             "automática, a veces imitando movimientos o decisiones humanas.",
}


def extraer_tema_pregunta(texto_normalizado):
    """
    Detecta si el mensaje del usuario tiene forma de pregunta de definición
    (ej: "que es el sol", "que son los atomos", "quien es python") y extrae
    el tema principal de la pregunta.

    Parámetros:
        texto_normalizado (str): mensaje del usuario ya normalizado.

    Retorna:
        str o None: el tema detectado (ej: "sol"), o None si el mensaje
                    no tiene forma de pregunta de definición.
    """
    # Cada expresión regular representa una forma distinta de preguntar "qué es algo".
    # El grupo (.+) captura el tema sobre el que se pregunta.
    patrones_de_pregunta = [
        r"^que es (?:un |una |el |la |los |las )?(.+)$",
        r"^que son (?:unos |unas |los |las )?(.+)$",
        r"^quien es (.+)$",
        r"^quienes son (.+)$",
        r"^que significa (.+)$",
        r"^sabes que es (?:un |una |el |la |los |las )?(.+)$",
        r"^me puedes explicar que es (?:un |una |el |la |los |las )?(.+)$",
    ]

    for patron in patrones_de_pregunta:
        coincidencia = re.match(patron, texto_normalizado)
        if coincidencia:
            return coincidencia.group(1).strip()

    return None


def buscar_definicion(tema):
    """
    Busca un tema dentro del diccionario de cultura general.
    Primero intenta una coincidencia exacta, y si no la encuentra,
    revisa si alguna de las palabras clave del diccionario aparece
    como palabra suelta dentro del tema (ej: tema="un robot casero"
    debería encontrar la definición de "robot").

    Parámetros:
        tema (str): tema extraído de la pregunta del usuario.

    Retorna:
        str o None: la definición encontrada, o None si no existe.
    """
    if tema in DICCIONARIO_GENERAL:
        return DICCIONARIO_GENERAL[tema]

    palabras_del_tema = tema.split()
    for clave, definicion in DICCIONARIO_GENERAL.items():
        if clave in palabras_del_tema:
            return definicion

    return None


def responder_pregunta_general(texto_normalizado):
    """
    Función principal del módulo: recibe el mensaje normalizado del usuario
    y, si es una pregunta de definición que el bot conoce, devuelve la respuesta.

    Parámetros:
        texto_normalizado (str): mensaje del usuario ya normalizado.

    Retorna:
        str o None: la definición encontrada, o None si no aplica o no se conoce el tema.
    """
    tema = extraer_tema_pregunta(texto_normalizado)

    if tema is None:
        return None

    # Quitamos signos de interrogación sueltos que pudieran haber quedado.
    tema = tema.strip("? ")

    return buscar_definicion(tema)
