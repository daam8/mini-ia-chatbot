"""
nlp_utils.py
------------
Este módulo contiene funciones relacionadas con el procesamiento de texto (NLP).
Aquí "simulamos" una pequeña parte de inteligencia artificial: en lugar de usar
únicamente "if mensaje == 'hola'", el bot compara qué tan PARECIDO es el mensaje
del usuario a las frases que ya conoce, usando la librería estándar difflib.

Todas las funciones están comentadas para poder explicarlas fácilmente en clase.
"""

import unicodedata
import string
from difflib import SequenceMatcher


def quitar_acentos(texto):
    """
    Elimina tildes y acentos de un texto.
    Ejemplo: 'cómo estás' -> 'como estas'

    Parámetros:
        texto (str): texto original con posibles acentos.

    Retorna:
        str: texto sin acentos.
    """
    # NFKD separa cada letra acentuada en (letra base + acento)
    texto_normalizado = unicodedata.normalize("NFKD", texto)
    # Nos quedamos solo con los caracteres que NO son marcas de acento (Mn)
    return "".join(
        caracter for caracter in texto_normalizado
        if unicodedata.category(caracter) != "Mn"
    )


def normalizar_texto(texto):
    """
    Prepara un texto para ser comparado:
    1. Lo convierte a minúsculas.
    2. Le quita los acentos.
    3. Le quita los signos de puntuación.
    4. Le quita espacios extra al inicio y al final.

    Esta función es clave: gracias a ella, el bot entiende igual
    "¡HOLA!", "Hola" y "hola " como el mismo mensaje.

    Parámetros:
        texto (str): mensaje original escrito por el usuario.

    Retorna:
        str: mensaje limpio y estandarizado.
    """
    texto = texto.lower()
    texto = quitar_acentos(texto)

    # Eliminamos signos de puntuación (¡, !, ¿, ?, ,, etc.), PERO conservamos
    # los operadores matemáticos (+, -, *, /) para que el bot pueda seguir
    # reconociendo operaciones como "5 + 3" después de normalizar el texto.
    operadores_matematicos = "+-*/"
    signos = "".join(c for c in (string.punctuation + "¡¿") if c not in operadores_matematicos)
    texto = "".join(caracter for caracter in texto if caracter not in signos)

    return texto.strip()


def calcular_similitud(texto_a, texto_b):
    """
    Calcula qué tan parecidas son dos frases, devolviendo un número entre 0 y 1.
    0 significa "totalmente diferentes" y 1 significa "idénticas".

    Se usa SequenceMatcher, que viene incluido en Python (librería difflib),
    por lo que no es necesario instalar ninguna librería externa.

    Parámetros:
        texto_a (str): primera frase a comparar.
        texto_b (str): segunda frase a comparar.

    Retorna:
        float: porcentaje de similitud (0.0 a 1.0).
    """
    return SequenceMatcher(None, texto_a, texto_b).ratio()


def obtener_palabras(texto):
    """
    Divide un texto en una lista de palabras individuales.

    Parámetros:
        texto (str): texto ya normalizado.

    Retorna:
        list: lista de palabras (strings).
    """
    return texto.split()


def palabras_son_parecidas(palabra_a, palabra_b, umbral=0.82):
    """
    Compara dos palabras individuales (no frases completas) y dice si son
    prácticamente la misma palabra, aunque tengan una pequeña diferencia
    (ej: "ayuda" y "ayudar", o "grasias" y "gracias").

    Parámetros:
        palabra_a (str): primera palabra.
        palabra_b (str): segunda palabra.
        umbral (float): qué tan parecidas deben ser para considerarse iguales.

    Retorna:
        bool: True si las palabras se consideran equivalentes.
    """
    if palabra_a == palabra_b:
        return True
    return calcular_similitud(palabra_a, palabra_b) >= umbral


def calcular_similitud_por_palabras(texto_mensaje, texto_patron):
    """
    Compara dos frases PALABRA POR PALABRA, en lugar de comparar toda la
    frase de un solo golpe (que es lo que hace calcular_similitud).

    Esto es muy importante porque un mensaje largo como "en que me puedes
    ayudar" y un patrón corto como "ayuda" se ven muy diferentes si se
    comparan letra por letra, pero SÍ comparten una palabra clave si se
    revisan palabra por palabra.

    Se calcula qué porcentaje de las palabras del patrón aparecen (exactas
    o muy parecidas) dentro del mensaje del usuario.

    Parámetros:
        texto_mensaje (str): mensaje del usuario, ya normalizado.
        texto_patron (str): patrón guardado en la base de conocimiento, normalizado.

    Retorna:
        float: proporción de palabras del patrón encontradas en el mensaje (0.0 a 1.0).
    """
    palabras_mensaje = obtener_palabras(texto_mensaje)
    palabras_patron = obtener_palabras(texto_patron)

    if not palabras_patron:
        return 0.0

    palabras_encontradas = 0
    for palabra_patron in palabras_patron:
        if any(palabras_son_parecidas(palabra_patron, palabra_msj) for palabra_msj in palabras_mensaje):
            palabras_encontradas += 1

    return palabras_encontradas / len(palabras_patron)


def contiene_palabra_clave(texto, palabras_clave):
    """
    Revisa si alguna palabra clave de una lista aparece dentro del texto.
    Útil para detectar intenciones simples, por ejemplo: números en una
    operación matemática o palabras como "hora" y "fecha".

    Parámetros:
        texto (str): texto normalizado del usuario.
        palabras_clave (list): lista de palabras a buscar.

    Retorna:
        bool: True si encuentra al menos una palabra clave, False si no.
    """
    palabras_del_texto = obtener_palabras(texto)
    return any(palabra in palabras_del_texto for palabra in palabras_clave)
