"""
chatbot.py
----------
Este es el "cerebro" del chatbot. Aquí se decide qué responder
según el mensaje que escribe el usuario.

Flujo de decisión (así se lo puedes explicar a la profesora):
    1. ¿Es un comando especial? (hora, fecha, operación matemática)
    2. Si no, ¿se parece a alguna categoría de la base de conocimiento?
       (usando comparación de similitud de texto, no if/elif interminables)
    3. Si tampoco, se devuelve None para indicar que el bot no entendió,
       y main.py se encarga de ofrecer la opción de "enseñarle" al bot.
"""

import random

from src.nlp_utils import normalizar_texto, calcular_similitud, calcular_similitud_por_palabras
from src.utilidades import (
    obtener_hora_actual,
    obtener_fecha_actual,
    es_operacion_matematica,
    resolver_operacion_matematica,
)
from src.cultura_general import responder_pregunta_general

# Umbral mínimo de similitud para considerar que el bot "entendió" el mensaje.
# Se puede ajustar: más alto = más estricto, más bajo = más flexible.
# Se bajó de 0.75 a 0.6 porque ahora también comparamos palabra por palabra,
# lo que da resultados más flexibles y "naturales" en la conversación.
UMBRAL_SIMILITUD = 0.6


def procesar_comando_especial(texto_normalizado):
    """
    Revisa si el mensaje del usuario corresponde a una función especial
    del bot (hora, fecha o una operación matemática), en lugar de una
    pregunta de la base de conocimiento.

    Parámetros:
        texto_normalizado (str): mensaje del usuario ya normalizado.

    Retorna:
        str o None: la respuesta especial si aplica, o None si no aplica.
    """
    palabras = texto_normalizado.split()

    if "hora" in palabras:
        return f"Son las {obtener_hora_actual()}."

    if "fecha" in palabras or "dia" in palabras:
        return f"Hoy es {obtener_fecha_actual()}."

    if es_operacion_matematica(texto_normalizado):
        return resolver_operacion_matematica(texto_normalizado)

    return None


def buscar_mejor_categoria(texto_normalizado, base_conocimiento):
    """
    Compara el mensaje del usuario contra TODOS los patrones guardados
    en la base de conocimiento, y devuelve la categoría con mayor similitud,
    junto con su puntaje.

    Esta es la parte que simula "inteligencia": el bot no necesita que el
    usuario escriba exactamente "hola", con que se parezca es suficiente.

    Para decidir el puntaje se combinan TRES estrategias, y se toma la más alta:
        1. Similitud de la frase completa, letra por letra (calcular_similitud).
        2. Similitud palabra por palabra (calcular_similitud_por_palabras), que
           permite detectar coincidencias aunque el usuario escriba una frase
           más larga o distinta a la guardada (ej: "en que me puedes ayudar"
           reconoce la palabra clave "ayuda").
        3. Un bono si el patrón aparece completo, tal cual, dentro del mensaje.

    Parámetros:
        texto_normalizado (str): mensaje del usuario ya normalizado.
        base_conocimiento (dict): diccionario con categorías, patrones y respuestas.

    Retorna:
        tuple: (nombre_categoria, mejor_puntaje) o (None, 0) si no hay coincidencias.
    """
    mejor_categoria = None
    mejor_puntaje = 0.0

    for categoria, contenido in base_conocimiento.items():
        for patron in contenido.get("patrones", []):
            patron_normalizado = normalizar_texto(patron)

            puntaje_por_caracteres = calcular_similitud(texto_normalizado, patron_normalizado)
            puntaje_por_palabras = calcular_similitud_por_palabras(texto_normalizado, patron_normalizado)
            puntaje = max(puntaje_por_caracteres, puntaje_por_palabras)

            # Bono extra: si el patrón aparece completo dentro del mensaje
            # (ej: usuario escribe "hola, buenas tardes profe"), subimos el puntaje.
            if patron_normalizado in texto_normalizado:
                puntaje = max(puntaje, 0.9)

            if puntaje > mejor_puntaje:
                mejor_puntaje = puntaje
                mejor_categoria = categoria

    return mejor_categoria, mejor_puntaje


def generar_respuesta(mensaje_usuario, base_conocimiento):
    """
    Función principal del chatbot: recibe el mensaje del usuario "crudo"
    (tal cual lo escribió) y devuelve la respuesta que debe mostrarse.

    Parámetros:
        mensaje_usuario (str): mensaje original escrito por el usuario.
        base_conocimiento (dict): base de conocimiento cargada desde JSON.

    Retorna:
        str o None: la respuesta generada, o None si el bot no entendió nada
                    y se debería activar el modo de aprendizaje.
    """
    texto_normalizado = normalizar_texto(mensaje_usuario)

    # Paso 1: revisar si es un comando especial (hora, fecha, operación matemática)
    respuesta_especial = procesar_comando_especial(texto_normalizado)
    if respuesta_especial is not None:
        return respuesta_especial

    # Paso 2: revisar si es una pregunta de cultura general (ej: "que es el sol")
    respuesta_general = responder_pregunta_general(texto_normalizado)
    if respuesta_general is not None:
        return respuesta_general

    # Paso 3: buscar la categoría más parecida en la base de conocimiento
    categoria, puntaje = buscar_mejor_categoria(texto_normalizado, base_conocimiento)

    if categoria is not None and puntaje >= UMBRAL_SIMILITUD:
        respuestas_posibles = base_conocimiento[categoria]["respuestas"]
        return random.choice(respuestas_posibles)

    # Paso 4: el bot no entendió el mensaje
    return None
