"""
utilidades.py
-------------
Funciones auxiliares que le dan al chatbot "superpoderes" extra,
además de responder preguntas de la base de conocimiento:
- Decir la hora y la fecha actual.
- Resolver operaciones matemáticas simples escritas en texto.

Estas funciones muestran manejo de módulos estándar de Python
(datetime, re) y buen uso de funciones con un solo propósito cada una.
"""

import re
from datetime import datetime


def obtener_hora_actual():
    """
    Retorna la hora actual del sistema en formato HH:MM:SS.

    Retorna:
        str: hora actual formateada.
    """
    ahora = datetime.now()
    return ahora.strftime("%H:%M:%S")


def obtener_fecha_actual():
    """
    Retorna la fecha actual del sistema en formato día/mes/año.

    Retorna:
        str: fecha actual formateada.
    """
    ahora = datetime.now()
    return ahora.strftime("%d/%m/%Y")


def es_operacion_matematica(texto):
    """
    Detecta si un texto normalizado parece ser una operación matemática
    simple, por ejemplo: "5 + 3", "10 * 2", "20 / 4".

    Se apoya en una expresión regular que busca: número, operador, número.

    Parámetros:
        texto (str): texto normalizado del usuario.

    Retorna:
        bool: True si el texto tiene forma de operación matemática.
    """
    patron = r"^\s*-?\d+(\.\d+)?\s*[\+\-\*\/x]\s*-?\d+(\.\d+)?\s*$"
    return re.match(patron, texto) is not None


def resolver_operacion_matematica(texto):
    """
    Resuelve una operación matemática simple de dos números
    (suma, resta, multiplicación o división).

    Parámetros:
        texto (str): texto normalizado, ej: "10 * 2".

    Retorna:
        str: mensaje con el resultado de la operación,
             o un mensaje de error si no se pudo calcular
             (por ejemplo, división entre cero).
    """
    # Reemplazamos la 'x' que a veces se usa como signo de multiplicar
    texto = texto.replace("x", "*")

    # Extraemos los dos números y el operador usando una expresión regular
    coincidencia = re.match(
        r"^\s*(-?\d+(?:\.\d+)?)\s*([\+\-\*\/])\s*(-?\d+(?:\.\d+)?)\s*$",
        texto
    )

    if not coincidencia:
        return "No pude identificar los números de esa operación."

    numero_1 = float(coincidencia.group(1))
    operador = coincidencia.group(2)
    numero_2 = float(coincidencia.group(3))

    if operador == "+":
        resultado = numero_1 + numero_2
    elif operador == "-":
        resultado = numero_1 - numero_2
    elif operador == "*":
        resultado = numero_1 * numero_2
    elif operador == "/":
        if numero_2 == 0:
            return "No puedo dividir entre cero."
        resultado = numero_1 / numero_2
    else:
        return "Operador no reconocido."

    # Si el resultado es un número entero (ej: 4.0), lo mostramos sin decimales.
    if resultado == int(resultado):
        resultado = int(resultado)

    return f"El resultado es: {resultado}"
