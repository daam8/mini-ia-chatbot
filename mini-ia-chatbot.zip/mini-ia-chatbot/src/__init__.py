# Este archivo convierte la carpeta "src" en un paquete de Python,
# permitiendo importar sus módulos con "from src.modulo import funcion".
